<?php 
    header("location:dashboard/index.php");
?>